package midlab1.datastructure;

class StackException extends RuntimeException {
    public StackException(){
        super();
    }
    public StackException(String err) {
        super(err);
    }
}