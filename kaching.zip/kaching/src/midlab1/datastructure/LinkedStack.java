package midlab1.datastructure;

public class LinkedStack<T> implements Stack<T> {
    private Node<T> top;
    private int numElements = 0;

    @Override
    public int size() {
        return (numElements);
    }

    @Override
    public boolean isEmpty() { /* checks if the stack is empty */
        return (top == null);
    }

    @Override
    public T top() throws StackException {
        if (isEmpty())
            throw new StackException("Stack is empty");
        return top.getInfo();
    }

    @Override
    public T pop() throws StackException { /* removes the top data from the stack */
        Node<T> temp;
        if (isEmpty())
            throw new StackException("Stack underflow");
        temp = top;
        top = top.getLink();
        return temp.getInfo();
    }

    @Override
    public void push(T item) throws StackException { /* push the data into the stack */
        Node<T> newNode = new Node<>();
        newNode.setInfo(item);
        newNode.setLink(top);
        top = newNode;

    }
    @Override
    public T peek() throws StackException { /* looks at the top of the stack*/
        if (isEmpty()) throw new StackException("The stack is empty");
        else
            return top.getInfo();
    }

    @Override
    public void clear() { /* clear the stacked data */
        while(top != null){
            top = top.getLink();
            if (top.getInfo() == null)
                top = null;
        }
    }

    @Override
    public int search(T item) { /* searches the item and return an integer */
        if(findData(item) == item)
            return 1;
        else
            return -1;
    }

    Node<T> findData(T node){
        Node<T> stack = top;
        while (stack != null) {
            if (stack.getInfo().equals(node))
                return stack;
            stack = stack.getLink();
        }
        return null;
    }
}