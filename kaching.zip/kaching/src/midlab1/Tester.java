package midlab1;

import midlab1.datastructure.LinkedStack;
import java.util.Scanner;

public class Tester {
    final private Scanner scanner = new Scanner(System.in);
    private static char symbol;
    private static double operand1 = 0, operand2 = 0, value = 0;
    private static LinkedStack<Character> stack = new LinkedStack<>();


    void run() {
        while (true) {
            System.out.println("\nWhat would you like to do?" +
                    "\n1. Convert an Infix to Postfix expression" +
                    "\n2. Convert a Postfix to Infix expression" +
                    "\n3. Evaluate a Numerical Postfix Expression" +
                    "\n4. Exit");
            byte choice = inputByte();
            switch (choice) {
                case 1: convertInflixToPostfix(input()); promptConversion();break;
                case 2: convertPostfixToInfix(input()); break;
                case 3: evaluateNum(input()); break;
                case 4: exit(); break;
                default: System.err.println("Invalid input. Try again."); run();
            }
        }
    }

    byte inputByte() {
        while (true) {
            try {
                System.out.print("Choice: ");
                return Byte.parseByte(scanner.next());
            } catch (NumberFormatException e) {
                System.err.println("Invalid input. Input a number only.");
            }
        }
    }

    String input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nInput an Expression: ");
        return scanner.nextLine();
    }

    //method that converts infixToPostfix
    private static String convertInflixToPostfix(String infixExpression) {
        String postfix = "";
        char topSymbol;
        for (int i = 0; i < infixExpression.length(); i++) {
            symbol = infixExpression.charAt(i);
            while (symbol != infixExpression.length()) {
                if (!isOperator(symbol))
                    postfix = postfix.concat(String.valueOf(symbol));
                else {
                    while (!stack.isEmpty() && precedence(stack.peek(), symbol)) {
                        topSymbol = stack.pop();
                        postfix = postfix.concat(String.valueOf(topSymbol));
                    }
                    if (stack.isEmpty() || symbol != ')')
                        stack.push(symbol);
                    else
                        topSymbol = stack.pop();
                }
            }
            while (!stack.isEmpty()) {
                topSymbol = stack.pop();
                postfix = postfix.concat(String.valueOf(topSymbol));
            }
        }
        return postfix;
    } //end of convert

    private static String convertPostfixToInfix(String postfixExpression) {
        String infix = "";
        return infix;
    }

    static void evaluateNum(String postfixExp) {
        LinkedStack<Double> operandStack = new LinkedStack<>();
        String[] expression = postfixExp.split(" ");

        System.out.println("\nPostfix Expression: " + postfixExp);
        System.out.println("==========================================================================================");
        System.out.printf("%-10s%10s%10s%10s%50s\n", "Symbol", "Operand 1", "Operand 2", "Value", "Operand Stack");
        System.out.println("==========================================================================================");

        for (int i = 0; i < expression.length; i++) {
            symbol = expression[i].charAt(0);
            if (!isOperator(symbol)) {
                double operand = Double.parseDouble(String.valueOf(symbol));
                operandStack.push(operand);
            } else {
                operand1 = operandStack.pop();
                operand2 = operandStack.pop();
                value = postEval(operand1, operand2, symbol);
                operandStack.push(value);
            }
            System.out.printf("%-10s%10s%10s%10s%50s\n", symbol, operand1, operand2, value, operandStack.toString());
        }
        System.out.println("\nValue: " + value);
        operandStack.pop();
    }

    static int precedencex(char c){
        return switch (c) {
            case '+', '-' -> 1;
            case '*', '/' -> 2;
            case '^' -> 3;
            default -> -1; };
    }

    static double postEval(double a, double b, char o) {
        switch (o) {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/':
                if (a != 0) { return b / a;
                } else { throw new UnsupportedOperationException("Undefined!"); }
            case '^': return Math.pow(b,a); }
        return 0.0;
    }

    /* checks if the symbol is operator or not */
    private static boolean isOperator(char o){
        return o == '+' || o == '-' || o == '*' || o == '/' || o == '^';
    }

    /* checks the precedence of two operator and return a boolean value */
    private static boolean precedence(char optr1, char optr2){
        if (optr1 == '+' || optr1 == '-' || optr1 == '*' && optr2 == '*' || optr1 == '/' && optr2 == '/')
            return false;
        if (optr1 == '*' || optr1 == '/' && optr2 == '+' || optr2 == '-')
            return true;
        return optr1 == '^';
    }

    void promptConversion() {
        System.out.println("\n\tConverting Infix to Postfix Expression" +
                "\n================================================");
        System.out.printf("%-10s%10s%30s", "Symbol", "operatorStack", "postfixExpression");
        System.out.println("================================================");
//        while(symbol != userInput.length()) { //TODO: iteration that prints the data into a table
//            for (int i = 0; i < )
//
//
//            System.out.printf("%-10s", );
    }



    boolean loop() {
        System.out.println("Would you like to rerun the program? (y/n): ");
        String choice = scanner.nextLine();
        return choice.equalsIgnoreCase("y");
    }

    void exit() {
        System.out.println("\nGoodbye!");
        System.exit(0);
    }

    public static void main(String[] args) {
        Tester tester = new Tester();
        tester.run();
    }
}
